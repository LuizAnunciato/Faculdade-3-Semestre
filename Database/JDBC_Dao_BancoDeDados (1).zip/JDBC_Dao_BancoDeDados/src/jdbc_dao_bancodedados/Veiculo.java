package jdbc_dao_bancodedados;

public class Veiculo {
    int ano;
    String placa;
    String cor;
    String modelo;
}
