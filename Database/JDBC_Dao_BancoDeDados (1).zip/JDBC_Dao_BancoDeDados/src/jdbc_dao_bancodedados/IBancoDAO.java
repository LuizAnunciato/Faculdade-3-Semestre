package jdbc_dao_bancodedados;

import java.util.List;

public interface IBancoDAO {
    
    void SalvarCliente(Cliente c);
    
    void ExcluirCliente(Cliente c);
    
    List<Cliente> ListarCliente();
}
