package jdbc_dao_bancodedados;

public class Cliente {
    int id;
    String nome;
    String cpf;
}
