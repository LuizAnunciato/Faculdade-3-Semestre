package jdbc_dao_bancodedados;

import java.util.ArrayList;
import java.util.List;

public class MemoriaClienteDAO implements IBancoDAO {
    
    private List<Cliente> bancoMemoria;
    
    public MemoriaClienteDAO(){
        bancoMemoria = new ArrayList<Cliente>();
    }
    
    @Override
    public void SalvarCliente(Cliente c){
        bancoMemoria.add(c);
    }
    
    @Override
    public void ExcluirCliente(Cliente c){
        bancoMemoria.remove(c);
    }
    
    @Override
    public List<Cliente> ListarCliente(){
        return bancoMemoria
    }
}
