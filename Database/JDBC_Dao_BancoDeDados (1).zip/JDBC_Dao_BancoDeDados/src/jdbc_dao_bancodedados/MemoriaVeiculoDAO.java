/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc_dao_bancodedados;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Stefano
 */
public class MemoriaVeiculoDAO implements IBancoDAO {
    
    private List<Veiculo> bancoMemoria;
    
    public MemoriaVeiculoDAO()
    {
        bancoMemoria = new ArrayList<Veiculo>();
    }

    @Override
    public void SalvarCliente(Veiculo c) {
        bancoMemoria.add(v);
    }

    @Override
    public void ExcluirCliente(Veiculo v) {
        bancoMemoria.remove(v);
    }

    @Override
    public List<Veiculo> ListarVeiculo() {
        return bancoMemoria;
    }   
}
